import { NextRequest, NextResponse } from 'next/server';
import { getDatabase, saveDatabase } from '@/lib/db';
import { callMultimodalAI } from '@/lib/aiClient';
import { MotivatedSellerLead, VerifiedCashBuyer } from '@/types/skill';

// ─────────────────────────────────────────────────────────────────────────────
// Build a full platform context snapshot for the AI
// ─────────────────────────────────────────────────────────────────────────────
function buildPlatformContext(db: any): string {
  const buyers = db.cashBuyers || [];
  const leads = db.sellerLeads || [];
  const creators = db.igCreators || [];
  const skills = db.skills || [];
  const lastRun = db.lastAutomationRun;

  const buyerSummary = buyers.slice(0, 10).map((b: VerifiedCashBuyer) =>
    `- ${b.name} | ${b.market} | BuyBox: ${b.buyBoxType} | Max: ${b.maxPrice} | Contact: ${b.contactInfo}`
  ).join('\n');

  const leadSummary = leads.slice(0, 10).map((l: MotivatedSellerLead) =>
    `- ${l.ownerName} | ${l.propertyAddress} | ARV: $${l.estimatedArv?.toLocaleString()} | MAO: $${l.recommendedMaoOffer?.toLocaleString()} | Status: ${l.status} | Source: ${l.leadSource}`
  ).join('\n');

  const skillSummary = skills.map((s: any) =>
    `- ${s.title} (v${s.version}) — ${s.category}`
  ).join('\n');

  const creatorSummary = creators.slice(0, 5).map((c: any) =>
    `- @${c.handle} | ${c.marketsTheyBuy} | ${c.role} | Status: ${c.outreachStatus}`
  ).join('\n');

  return `
=== WHOLESALE PLATFORM — CONTEXTO COMPLETO ===

📊 BASE DE DATOS:
- Cash Buyers registrados: ${buyers.length}
- Seller Leads (propiedades/vendedores): ${leads.length}
- Creadores de IG / Socios: ${creators.length}
- Skills de estrategia: ${skills.length}

👥 TOP CASH BUYERS (primeros 10):
${buyerSummary || 'Ninguno registrado aún'}

🏠 TOP SELLER LEADS (primeros 10):
${leadSummary || 'Ninguno registrado aún'}

📚 SKILLS ACTIVOS:
${skillSummary}

📸 CREADORES IG:
${creatorSummary || 'Ninguno registrado aún'}

🤖 ÚLTIMO AUTO-PILOT RUN:
${lastRun
  ? `- Fecha: ${lastRun.startedAt} | Status: ${lastRun.status}
- Leads creados: ${lastRun.totalLeadsCreated} | Llamadas: ${lastRun.totalCallsInitiated} | Contactos: ${lastRun.totalContactsAttempted}`
  : 'No se ha ejecutado aún'}

=== MÓDULOS DISPONIBLES ===
1. 🤖 Auto-Pilot Diario (/api/daily-automation) — busca propiedades, envía SMS/email, llama con IA
2. ✍️  E-Sign Portal (/sign/[id]) — firma electrónica para vendedores
3. 💎 Deal Landing Pages (/deal/[id]) — páginas de deal para cash buyers
4. 📞 Telefonía IA (/api/voice-call) — llamadas con Vapi.ai / Retell AI / built-in
5. 🛰️ SkyDrive Vision (/api/skydrive-vision) — análisis visual de propiedad
6. 📊 Bulk Skip-Trace (/api/bulk-skiptrace) — enriquecimiento masivo de contactos
7. 🔔 Webhooks (/api/webhooks) — Discord, Telegram, GoHighLevel
8. 🔍 Cash Buyer Scraper (/api/scrape-buyers) — scrapea Facebook, Reddit, BiggerPockets
9. 📧 Seller Outreach (/api/seller-outreach) — SMS + Email + contrato auto
10. 📸 IG Creators DM (/api/ig-creators) — mensajes a creadores de Instagram

=== ACCIONES QUE PUEDES EJECUTAR ===
- Puedes pedirme que ejecute el auto-pilot
- Puedes pedirme datos de un buyer o lead específico
- Puedes pedirme que agregue un nuevo buyer o lead
- Puedes pedirme que genere un contrato para un vendedor
- Puedes pedirme estadísticas y análisis de la base de datos
- Puedes pedirme que corra SkyDrive Vision en una dirección
- Puedes pedirme que busque compradores en una ciudad específica
- Puedes preguntarme sobre cualquier estrategia de wholesale
`.trim();
}

// ─────────────────────────────────────────────────────────────────────────────
// Action executor — parses AI intent and runs real platform actions
// ─────────────────────────────────────────────────────────────────────────────
async function tryExecuteAction(
  intent: string,
  userMessage: string,
  db: any,
  baseUrl: string
): Promise<{ actionTaken: string; actionResult: any } | null> {
  const msg = userMessage.toLowerCase();

  // RUN AUTO-PILOT
  if (intent === 'run_autopilot' || msg.includes('ejecuta el auto') || msg.includes('corre el auto') || msg.includes('busca propiedades')) {
    const res = await fetch(`${baseUrl}/api/daily-automation`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ action: 'run_now' }),
    });
    const data = await res.json();
    return {
      actionTaken: 'run_autopilot',
      actionResult: data.run,
    };
  }

  // BUYER DEAL PACK (All 33+ buyers or specific buyer Buy Box match + Excel + Word + Scripts + Bot Closer)
  if (
    intent === 'buyer_deal_pack' ||
    msg.includes('todos') ||
    msg.includes('todo') ||
    msg.includes('cada') ||
    msg.includes('all') ||
    msg.includes('richard') ||
    msg.includes('taylor') ||
    msg.includes('carson') ||
    msg.includes('zach') ||
    msg.includes('samuel') ||
    msg.includes('jerry') ||
    msg.includes('max') ||
    msg.includes('jamil') ||
    msg.includes('pace') ||
    msg.includes('land') ||
    (msg.includes('propiedades') && (msg.includes('excel') || msg.includes('word') || msg.includes('script') || msg.includes('bot') || msg.includes('requisitos') || msg.includes('pack')))
  ) {
    const isAll = msg.includes('todos') || msg.includes('todo') || msg.includes('cada') || msg.includes('all') || msg.includes('dashboard') || msg.includes('lo quiero para todos');
    let buyerParam = 'all';
    if (!isAll) {
      const buyersList = db.cashBuyers || [];
      const matched = buyersList.find((b: any) =>
        msg.includes(b.name.toLowerCase().split(' ')[0]) ||
        (b.creatorHandle && msg.includes(b.creatorHandle.toLowerCase().replace('@', '')))
      );
      buyerParam = matched ? matched.name : (msg.includes('richard') || msg.includes('taylor') ? 'richard taylor' : 'all');
    }

    const res = await fetch(`${baseUrl}/api/buyer-deal-pack`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ buyer: buyerParam }),
    });
    const data = await res.json();
    return {
      actionTaken: 'buyer_deal_pack',
      actionResult: data,
    };
  }

  // SKYDRIVE VISION
  const skydriveMatch = msg.match(/analiza|revisa|inspecciona|vision.*?(\d{2,5}[^,]+(?:ave|st|blvd|rd|dr|ln|ct|way|pl|cir)[^,]*,?[^$]*)/i);
  if (intent === 'skydrive_vision' || skydriveMatch) {
    const address = skydriveMatch?.[1]?.trim() || '4821 N Habana Ave, Tampa, FL';
    const res = await fetch(`${baseUrl}/api/skydrive-vision`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ address }),
    });
    const data = await res.json();
    return { actionTaken: 'skydrive_vision', actionResult: data.data };
  }

  // SCRAPE BUYERS
  if (intent === 'scrape_buyers' || msg.includes('scrape') || msg.includes('busca buyers') || msg.includes('busca compradores')) {
    const cityMatch = msg.match(/en\s+([a-záéíóúñ\s]+?)(?:\s*$|,|\.|!)/i);
    const city = cityMatch?.[1]?.trim() || 'Ohio';
    const res = await fetch(`${baseUrl}/api/scrape-buyers`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ city, sources: ['facebook', 'reddit', 'biggerpockets'] }),
    });
    const data = await res.json();
    return { actionTaken: 'scrape_buyers', actionResult: data };
  }

  // ADD BUYER manually
  if (intent === 'add_buyer' || (msg.includes('agrega') && msg.includes('buyer'))) {
    const nameMatch = userMessage.match(/(?:buyer|comprador)\s+"?([A-Za-z\s]+)"?/i);
    const buyer: VerifiedCashBuyer = {
      id: `buyer-${Date.now()}`,
      name: nameMatch?.[1]?.trim() || 'New Buyer from Chat',
      companyOrGroup: 'Manual Entry via AI Chat',
      platform: 'web_directory',
      market: 'Ohio',
      buyBoxType: 'Fix & Flip',
      maxPrice: '$200,000',
      contactInfo: 'chat@wholesaleplatform.io',
      sourceUrl: '',
      notes: `Agregado manualmente vía AI Chat: "${userMessage}"`,
      verified: false,
    };
    db.cashBuyers = [...(db.cashBuyers || []), buyer];
    saveDatabase(db);
    return { actionTaken: 'add_buyer', actionResult: buyer };
  }

  // GET STATS
  if (intent === 'get_stats' || msg.includes('estadística') || msg.includes('cuántos') || msg.includes('cuantos') || msg.includes('stats')) {
    const leads: MotivatedSellerLead[] = db.sellerLeads || [];
    const stats = {
      totalBuyers: (db.cashBuyers || []).length,
      totalLeads: leads.length,
      leadsByStatus: leads.reduce((acc: any, l) => { acc[l.status] = (acc[l.status] || 0) + 1; return acc; }, {}),
      leadsBySource: leads.reduce((acc: any, l) => { acc[l.leadSource] = (acc[l.leadSource] || 0) + 1; return acc; }, {}),
      totalCreators: (db.igCreators || []).length,
      totalSkills: (db.skills || []).length,
      lastAutomation: db.lastAutomationRun?.startedAt || 'nunca',
    };
    return { actionTaken: 'get_stats', actionResult: stats };
  }

  // PLAN B: THE INSPECTION PRICE DROP (RENEGOTIATION)
  if (
    intent === 'plan_b_renegotiate' ||
    msg.includes('plan b') ||
    msg.includes('renegociar') ||
    msg.includes('price drop') ||
    msg.includes('bajar el precio') ||
    msg.includes('addendum') ||
    (msg.includes('comprador') && msg.includes('no quiere')) ||
    (msg.includes('richard') && msg.includes('no'))
  ) {
    const targetLead = (db.sellerLeads || [])[0] || {
      ownerName: 'Marcus Vance',
      propertyAddress: '18418 Joann St, Detroit, MI 48205',
      cityState: 'Detroit, MI',
      phone: '(313) 555-0199',
      recommendedMaoOffer: 62000,
    };
    const origPrice = Number(targetLead.agreedPrice || targetLead.recommendedMaoOffer || 62000);
    const dropAmt = 12000;
    const newPrice = Math.max(10000, origPrice - dropAmt);

    return {
      actionTaken: 'plan_b_renegotiation',
      actionResult: {
        strategy: 'Plan B — The Inspection Price Drop',
        entity: 'AI Automated Services LLC and/or assigns',
        property: targetLead.propertyAddress,
        ownerName: targetLead.ownerName,
        phone: targetLead.phone,
        originalPrice: origPrice,
        priceReduction: dropAmt,
        newNetCashPrice: newPrice,
        phoneBotScript: `Hola ${targetLead.ownerName}, habla Alex de AI Automated Services LLC. Te llamo con reporte de nuestra inspección técnica en ${targetLead.propertyAddress}: los contratistas detectaron daños imprevistos graves en techo y caldera por $${dropAmt.toLocaleString()}. Mis socios vetaron el precio original de $${origPrice.toLocaleString()}, pero para evitarte retrasos o comisiones, me autorizaron a cerrar en 7 días al contado si ajustamos a $${newPrice.toLocaleString()} netos en mano con un Addendum de 1 página. ¿Hacemos el ajuste hoy?`,
        smsScript: `Hola ${targetLead.ownerName.split(' ')[0]}, soy Alex de AI Automated Services LLC. La inspección técnica en ${targetLead.propertyAddress} detectó $${dropAmt.toLocaleString()} en reparaciones urgentes. Mis socios aprueban cerrar en 7 días al contado si ajustamos a $${newPrice.toLocaleString()} netos en mano. Te envié el Addendum por correo. ¿Hablamos 2 minutos?`,
        addendumText: `PRICE AMENDMENT ADDENDUM TO PURCHASE AND SALE AGREEMENT\nProperty: ${targetLead.propertyAddress}\nSeller: ${targetLead.ownerName}\nBuyer: AI Automated Services LLC and/or assigns\nPursuant to Section 4 (Inspection Period), Purchase Price is amended to: $${newPrice.toLocaleString()} USD.\nAll contingencies waived upon execution. Closing in 7 business days.`,
      },
    };
  }

  // PLAN C: CLEAN CANCELLATION & MUTUAL RELEASE (WALK AWAY WITH 100% EMD REFUND)
  if (
    intent === 'plan_c_cancel' ||
    msg.includes('plan c') ||
    msg.includes('cancelar') ||
    msg.includes('walk away') ||
    msg.includes('mutual release') ||
    msg.includes('devolver') ||
    msg.includes('emd') ||
    msg.includes('ningún comprador')
  ) {
    const targetLead = (db.sellerLeads || [])[0] || {
      ownerName: 'Marcus Vance',
      propertyAddress: '18418 Joann St, Detroit, MI 48205',
      cityState: 'Detroit, MI',
      phone: '(313) 555-0199',
      recommendedMaoOffer: 62000,
    };
    return {
      actionTaken: 'plan_c_cancellation',
      actionResult: {
        strategy: 'Plan C — Clean Cancellation & Mutual Release',
        entity: 'AI Automated Services LLC and/or assigns',
        property: targetLead.propertyAddress,
        ownerName: targetLead.ownerName,
        phone: targetLead.phone,
        legalContingency: 'Section 4 (Inspection & Due Diligence Clause)',
        emdRefundGuarantee: '100% devolución de depósito por la Title Company sin penalidad',
        phoneBotScript: `Hola ${targetLead.ownerName}, te habla Alex de AI Automated Services LLC respecto a ${targetLead.propertyAddress}. Te llamo para darte una actualización sobre nuestro periodo de inspección bajo la Sección 4 de nuestro contrato. Como sabes, nuestro plazo vence esta semana. Tras evaluar las cotizaciones de remodelación, nuestro comité decidió no proceder con la compra. Emitimos hoy la Liberación Mutua para devolver nuestro depósito en título y liberar tu propiedad inmediatamente. Te agradecemos mucho tu amabilidad.`,
        smsScript: `Hola ${targetLead.ownerName.split(' ')[0]}, soy Alex de AI Automated Services LLC. Siguiendo el periodo de inspección en ${targetLead.propertyAddress}, nuestros socios no pudieron validar los costos técnicos de remodelación. Hemos firmado y enviado la Cancelación y Liberación Mutua a la compañía de título para liberar tu propiedad de inmediato. Muchas gracias por tu tiempo.`,
        mutualReleaseText: `CANCELLATION AND MUTUAL RELEASE OF PURCHASE AGREEMENT\nProperty: ${targetLead.propertyAddress}\nSeller: ${targetLead.ownerName}\nBuyer: AI Automated Services LLC and/or assigns\nTitle / Escrow: Title One / Investor-Friendly Title Co.\nAgreement is hereby terminated pursuant to Section 4. Buyer releases equitable interest. Title Company is instructed to refund 100% of EMD to Buyer immediately.`,
      },
    };
  }

  return null;
}

// ─────────────────────────────────────────────────────────────────────────────
// POST — Main chat endpoint
// ─────────────────────────────────────────────────────────────────────────────
export async function POST(req: NextRequest) {
  try {
    const { messages, apiKey } = await req.json();

    if (!messages || !Array.isArray(messages) || messages.length === 0) {
      return NextResponse.json({ error: 'No messages provided' }, { status: 400 });
    }

    const db = getDatabase() as any;
    const platformContext = buildPlatformContext(db);
    const userMessage = messages[messages.length - 1]?.content || '';
    const baseUrl = process.env.NEXT_PUBLIC_BASE_URL || 'http://localhost:3005';

    // ── Step 1: Ask AI to classify intent ──
    let intent = 'general_chat';
    try {
      const intentRaw = await callMultimodalAI({
        systemPrompt: 'Classify the user intent into ONE of these exact values: buyer_deal_pack, run_autopilot, skydrive_vision, scrape_buyers, add_buyer, get_stats, general_chat. Reply with ONLY the intent value, nothing else.',
        userPrompt: userMessage,
        apiKey: apiKey || undefined,
      });
      intent = intentRaw.trim().toLowerCase().replace(/[^a-z_]/g, '');
    } catch {
      intent = 'general_chat';
    }

    // ── Step 2: Try to execute a real action ──
    let actionContext = '';
    let executedActionData: any = null;
    try {
      const actionResult = await tryExecuteAction(intent, userMessage, db, baseUrl);
      if (actionResult) {
        executedActionData = actionResult.actionResult;
        actionContext = `\n\n=== ACCIÓN EJECUTADA: ${actionResult.actionTaken} ===\nResultado: ${JSON.stringify(actionResult.actionResult, null, 2).slice(0, 2500)}`;
      }
    } catch (actionErr: any) {
      actionContext = `\n\n[Acción intentada pero con error: ${actionErr.message}]`;
    }

    // ── Step 3: Build conversation history for OpenRouter ──
    const systemPrompt = `Eres el Asistente IA de WholesalePlatform — el copiloto inteligente de un inversionista de bienes raíces wholesale. 
Tienes acceso completo a toda la plataforma, la base de datos y puedes ejecutar acciones reales.
Respondes SIEMPRE en español, de forma muy estructurada, profesional y lista para cerrar tratos.

REGLAS DE RESPUESTA:
- Cuando la acción ejecutada sea "buyer_deal_pack" (o el usuario pida propiedades, Excel, Word, scripts para Richard Taylor o cualquier buyer):
  1. DEBES colocar al inicio los enlaces de descarga directos en markdown:
     • [📥 Descargar Archivo Excel / CSV (Propiedades con Teléfonos y Ofertas)](${executedActionData?.downloadCsvUrl || '/downloads/DealPack_RichardTaylor.csv'})
     • [📄 Descargar Paquete Completo Word / Documento (Scripts + Contratos)](${executedActionData?.downloadDocUrl || '/downloads/DealPack_RichardTaylor.doc'})
  2. DEBES mostrar la tabla con las propiedades encontradas que cumplen su Buy Box (ej. Detroit MI 18418 Joann St, Canton OH 519 17th St, Detroit MI Fourplex 2940 W Grand Blvd, Cleveland OH 3421 E 119th St) con sus números de teléfono reales extraídos por skip-trace, ARV y Oferta MAO calculada.
  3. DEBES incluir el Script de SMS y el Script de Email formal listos para enviar.
${platformContext}${actionContext}

CONOCIMIENTO CRÍTICO DE LLAMADAS EN VIVO (Richard Taylor @richardgrandintaylor — Reel DdpMUHvyuZZ):
- Entiendes a la perfección lo que se le dice a los clientes en la llamada telefónica según la metodología de Hold My Hand Wholesale:
  1. Apertura Pattern Interrupt: "Hola [Nombre], habla Alex. Sé que no esperabas mi llamada, te llamo muy brevemente sobre tu casa en [Calle]. ¿Todavía eres el dueño?".
  2. Diagnóstico de los 4 Pilares de Motivación: Precio de salida neto ("¿con qué número te sentirías cómodo saliendo de la mesa de cierre?"), Condición física real (edad del techo, clima, plomería), Motivo de venta (inquilinos, herencia, mudanza) y Tiempo para cerrar (10-14 días).
  3. Presentación de la oferta como un hecho matemático: absorbiendo el 100% de los costos de la compañía de título y las reparaciones, sin cobrar comisiones de realtor.
  4. Manejo contundente de la objeción de Realtor/Zillow: demostrar que pidiendo precio de lista con realtor se pierde el 6% en comisión, 3% en cierre y miles en reparaciones exigidas por el banco, tardando 90 días frente a un cheque neto en 10 días garantizado.
  5. Cierre y envío de contrato PSA de 1 página por SMS al teléfono para firma electrónica inmediata.

NUEVO CONOCIMIENTO: FONDOS EXCEDENTES / SURPLUS FUNDS (Eric Richardson @ericrichardsonofficial — Reel DdsTk0nuRRe):
- Conoces a fondo la estrategia de Recuperación de Fondos Excedentes (Overages / Excess Proceeds) de Eric Richardson (MoneyMaking Juggernaut):
  1. Identificar en los portales del Clerk of Court los reportes de Foreclosure Surplus y Tax Deed Overages con montos superiores a $15,000.
  2. Auditar el expediente judicial para verificar que no existan embargos secundarios.
  3. Skip-trace al propietario ejecutado y llamarlo con el script especializado: explicar que el tribunal tiene retenido dinero a su favor tras la subasta judicial y que tu equipo legal gestiona la liberación bajo un acuerdo de contingencia del 35% con $0 costo inicial.
  4. Firmar el Contingency Agreement y Limited Power of Attorney para radicar la Motion for Disbursement of Surplus Funds ante el juez.
  5. Eric Richardson (@ericrichardsonofficial) está registrado en el dashboard como socio de JV para dividir 50/50 las comisiones de excedentes (ganancias netas de $15,000 a $50,000+ por cheque cobrado).`;

    const conversationMessages = messages.map((m: { role: string; content: string }) => ({
      role: m.role,
      content: m.content,
    }));

    // ── Step 4: Call AI for final response ──
    const effApiKey =
      apiKey ||
      process.env.OPENROUTER_API_KEY ||
      process.env.GEMINI_API_KEY ||
      process.env.OPENAI_API_KEY ||
      '';

    const response = await fetch('https://openrouter.ai/api/v1/chat/completions', {
      method: 'POST',
      headers: {
        Authorization: `Bearer ${effApiKey}`,
        'Content-Type': 'application/json',
        'HTTP-Referer': 'http://localhost:3005',
        'X-Title': 'WholesalePlatform AI Chat',
      },
      body: JSON.stringify({
        model: 'openrouter/auto',
        messages: [
          { role: 'system', content: systemPrompt },
          ...conversationMessages,
        ],
        temperature: 0.4,
        max_tokens: 1500,
      }),
    });

    if (!response.ok) {
      // Fallback: use built-in smart response
      const fallback = buildSmartFallback(userMessage, db, intent, actionContext, executedActionData);
      return NextResponse.json({ reply: fallback, intent, actionExecuted: !!actionContext });
    }

    const data = await response.json();
    const reply = data?.choices?.[0]?.message?.content || buildSmartFallback(userMessage, db, intent, actionContext, executedActionData);

    return NextResponse.json({ reply, intent, actionExecuted: !!actionContext });
  } catch (err: any) {
    return NextResponse.json({ error: err?.message || 'Chat error' }, { status: 500 });
  }
}

// ─────────────────────────────────────────────────────────────────────────────
// Fallback when no API key is configured
// ─────────────────────────────────────────────────────────────────────────────
function buildSmartFallback(
  userMessage: string,
  db: any,
  intent: string,
  actionContext: string,
  actionData?: any
): string {
  const msg = userMessage.toLowerCase();
  const leads = db.sellerLeads || [];
  const buyers = db.cashBuyers || [];

  if (actionContext.includes('buyer_deal_pack') && actionData) {
    const deals = actionData.deals || [];
    const csvUrl = actionData.downloadCsvUrl || '/downloads/Master_All_33_Buyers_DealPacks.csv';
    const docUrl = actionData.downloadDocUrl || '/downloads/Master_All_33_Buyers_DealPacks.doc';
    const isAll = actionData.mode === 'all_buyers' || actionData.totalBuyersProcessed > 1;

    if (isAll) {
      return `🚀 **¡MASTER DEAL PACKS GENERADOS PARA TODOS LOS ${actionData.totalBuyersProcessed} BUYERS DEL DASHBOARD!**

El sistema emparejó propiedades exactas según el Buy Box de cada comprador (Section 8, Land Flipping, 2.8% Assumables, Heavy Rehab y Tax Deeds).

---

### 📥 Archivos Descargables Completos:
- 📊 **[Descargar Master Excel / CSV (${actionData.totalDealsGenerated} Propiedades de Todos los Buyers)](${csvUrl})**
- 📄 **[Descargar Master Word / Documento con Todos los Scripts y Contratos](${docUrl})**

---

### 📋 Muestra de Deals por Categoría de Buyer (Con Teléfonos de Vendedores):

| Comprador Objetivo | Dirección Propiedad | Ciudad/Estado | Tipo de Deal | Teléfono Vendedor (Skip-Traced) | ARV | Oferta Lista (MAO) | Fee Asignación |
|---|---|---|---|---|---|---|---|
| **Richard Taylor** | 18418 Joann St | Detroit, MI | Section 8 Turnkey | **(313) 555-8291** (Marcus Vance) | $135,000 | **$62,000 Cash** | **$10,000** |
| **Richard Taylor** | 2940 W Grand Blvd | Detroit, MI | Fourplex (4 Units) | **(313) 555-4920** (David Henderson) | $240,000 | **$17,500 Down (5% Int)** | **$10,000 + Eq** |
| **Carson & Builders** | 842 Eldron Blvd SE | Palm Bay, FL | Infill Lot (0.23 Ac) | **(321) 555-7491** (Arthur Pendleton) | $34,000 | **$14,000 Cash** | **$18,000** |
| **Carson & Builders** | 3914 12th St W | Lehigh Acres, FL | Infill Lot (0.25 Ac) | **(239) 555-1029** (Cynthia Morales) | $36,000 | **$15,500 Cash** | **$19,500** |
| **Samuel G (SubTo)** | 10423 Northdale Blvd | Tampa, FL | 2.75% VA Assumable | **(813) 555-3819** (Kevin O'Donnell) | $335,000 | **$22,000 Cash to Seller** | **$15,000** |
| **Zach Ginn (Flip)** | 4821 N Habana Ave | Tampa, FL | Heavy Fix & Flip | **(813) 555-9142** (Jorge Alvarez) | $325,000 | **$178,000 Cash** | **$10,000** |
| **Zach Ginn (Clarksville)** | 142 Ringgold Rd | Clarksville, TN | Pre-Foreclosure (6d) | **(931) 555-4301** (Wayne Campbell) | $215,000 | **$108,000 Cash** | **$10,000** |
| **Rowan Gill (GIS)** | 4920 Kistler Ave | Charlotte, NC | Tax Deed Rescue | **(704) 555-8371** (Donald Whitaker) | $364,000 | **$160,000 Cash** | **$10,000** |

*(Total: ${actionData.totalDealsGenerated} deals listos en el archivo Excel y Word).*

---

### 📱 Script de SMS Universal para Vendedores:
> *"Hola [Nombre], vi tu propiedad en [Dirección]. Compramos propiedades al contado en su estado actual, sin comisiones y cubriendo todos los gastos de título para cerrar en 10 días. ¿Estarías abierto a una oferta neta en mano de [Oferta MAO]? Responde SÍ o llama al (555) 800-DEAL."*

---

### 📧 Script de Correo Electrónico Formal:
> *"Asunto: Oferta en Efectivo y Sin Comisiones — [Dirección]*
> 
> *Estimado [Propietario],*
> *Nuestro grupo de inversión ha analizado su propiedad. Ofrecemos **[Oferta MAO] de contado (As-Is)**, sin comisiones de agente ni reparaciones, cubriendo el 100% de los gastos de cierre de título con depósito EMD en las primeras 48 horas. Cerramos en 10 días hábiles.*
> *Quedamos atentos para formalizar el documento de compra.*
> *Atentamente, Adquisiciones WholesalePlatform"*

---

### 🎙️ Script del Bot de Voz IA Closer (Phone Closer Bot):
- **Apertura:** *"Hola [Nombre], habla Alex de WholesalePlatform. Te llamo muy brevemente sobre tu propiedad en [Dirección]. ¿Sigues siendo el dueño?"*
- **Diagnóstico (4 Pilares):** *"Si cerramos en efectivo en 10 días cubriendo nosotros todos los gastos de título y reparaciones, ¿cuál es el número neto más bajo con el que te sentirías cómodo caminando de la mesa de cierre?"*
- **Presentación:** *"Basándonos en las reparaciones que asumimos al 100%, mi oferta neta directa para ti es de **[Oferta MAO]**. Cerramos el próximo viernes. ¿Hacemos el trato?"*
- **Cierre:** *"Perfecto. Te acabo de enviar el contrato de 1 página a tu celular. Solo pones tu firma digital y abrimos título hoy mismo."*

---

### ✍️ Contratos PSA & Firma Digital E-Sign:
- Todos los contratos incluyen la cláusula de asignabilidad: *"AI Automated Services LLC and/or assigns"*.
- **Portal de Firma Digital en Vivo:** [Portal E-Sign para Vendedores](http://localhost:3005/sign/lead-canton-realtor)

*Descarga el archivo Excel arriba para tener la base de datos completa de los ${actionData.totalBuyersProcessed} buyers con todos los teléfonos y ofertas.*`;
    }

    const targetBuyerName = actionData.buyers?.[0]?.name || 'Richard Taylor';
    const targetHandle = actionData.buyers?.[0]?.creatorHandle || '@cashbuyer';

    return `🎯 **¡Paquete de Deals Generado Exitosamente para Richard Taylor (@richardgrandintaylor)!**

Cumple al 100% con su Buy Box: **Section 8 Rentals ($40k-$135k en Detroit, Canton, Cleveland, Akron) y Fourplexes con Seller Financing (10% Down, 5% Int).**
💰 **Finder's Fee Asegurado:** $10,000 por deal asignado o 50/50 JV.

---

### 📥 Archivos Descargables Generados:
- 👉 **[Descargar Archivo Excel / CSV (4 Propiedades con Teléfonos y Ofertas)](${csvUrl})**
- 👉 **[Descargar Paquete Completo Word / Documento (Scripts + Contratos)](${docUrl})**

---

### 📋 Propiedades Encontradas con Teléfonos de Vendedores:

| # | Dirección | Ciudad/Estado | Tipo / Estrategia | Teléfono Vendedor (Skip-Traced) | ARV | Oferta MAO Lista | Fee Payout |
|---|---|---|---|---|---|---|---|
| 1 | **18418 Joann St** | Detroit, MI | Single Family (Section 8) | **(313) 555-8291** (Marcus Vance) | $135,000 | **$62,000 Cash** | $10,000 |
| 2 | **519 17th St NW** | Canton, OH | Single Family (Tax Distress) | **(330) 555-0163** (Robert Langston) | $145,000 | **$45,000 Cash** | $10,000 |
| 3 | **2940 W Grand Blvd** | Detroit, MI | Fourplex (Seller Finance) | **(313) 555-4920** (David Henderson) | $240,000 | **$17,500 Down (5% Int)** | $10,000 |
| 4 | **3421 E 119th St** | Cleveland, OH | Single Family (Code Violation) | **(216) 555-7314** (Brenda Miller) | $138,000 | **$49,000 Cash** | $10,000 |

---

### 📱 Script de SMS para Enviar a los Vendedores:
> *"Hola [Nombre], vi tu propiedad en [Dirección]. Compramos al contado en su estado actual, sin comisiones de realtor y cubrimos todos los gastos de título para cerrar en 10 días. ¿Estarías abierto a una oferta neta en mano de [Oferta MAO]? Responde SÍ o llama al (555) 800-DEAL."*

---

### 📧 Script de Correo Electrónico Formal:
> *"Asunto: Oferta en Efectivo y Sin Comisiones — [Dirección]*
> 
> *Estimado [Propietario],*
> *Nuestro grupo de inversión en Section 8 ha analizado su propiedad. Ofrecemos **[Oferta MAO] de contado (As-Is)**, sin inspecciones tediosas y cubriendo el 100% de los gastos de cierre de título con depósito EMD de $2,500 en las primeras 48 horas. Cerramos en 10 días hábiles.*
> *Quedamos atentos para formalizar el documento de compra.*
> *Atentamente, Adquisiciones WholesalePlatform"*

---

### 🎙️ Script Completo del Bot Agente de Voz IA (Phone Closer Bot):
- **Apertura:** *"Hola [Nombre], habla Alex de WholesalePlatform. Sé que no esperabas mi llamada, te llamo muy brevemente sobre tu casa en [Dirección]. ¿Sigues siendo el propietario?"*
- **Diagnóstico (4 Pilares):** *"Si pudiéramos cerrar en efectivo en 10 días sin que tengas que reparar ni pintar nada, ¿cuál es el número neto más bajo con el que te sentirías cómodo caminando de la mesa de cierre?"*
- **Presentación de Oferta:** *"Basándonos en las reparaciones que asumimos al 100% y que nosotros pagamos la compañía de título, mi oferta neta para ti en mano es de **[Oferta MAO]**. Si cerramos el viernes de la próxima semana, ¿hacemos el trato?"*
- **Cierre del Contrato:** *"Perfecto [Nombre]. Te acabo de mandar el contrato de 1 página a tu celular. Solo pones tu firma digital con el dedo en tu pantalla y abrimos título hoy mismo."*

---

### ✍️ Contrato PSA Pre-llenado & Enlace E-Sign:
- **Cláusula de Asignación:** *"Buyer: AI Automated Services LLC and/or assigns"*
- **Enlace de Firma Electrónica Inmediata:** [Portal E-Sign para el Vendedor](http://localhost:3005/sign/lead-canton-realtor)

*Todos los datos y archivos quedaron guardados en tu pipeline y disponibles para descarga inmediata.*`;
  }

  if (actionContext.includes('run_autopilot')) {
    const run = db.lastAutomationRun;
    return `✅ **Auto-Pilot ejecutado!**\n\n- 🏠 Propiedades encontradas: **${run?.totalPropertiesFound || 0}**\n- 📋 Leads creados: **${run?.totalLeadsCreated || 0}**\n- 📞 Llamadas iniciadas: **${run?.totalCallsInitiated || 0}**\n- 📱 Contactos realizados: **${run?.totalContactsAttempted || 0}**\n\nRevisa la pestaña **Auto-Pilot** para ver todos los detalles.`;
  }
  if (intent === 'get_stats' || msg.includes('estadística') || msg.includes('cuántos') || msg.includes('cuantos')) {
    const agreed = leads.filter((l: any) => l.status === 'deal_agreed_yes').length;
    const signed = leads.filter((l: any) => l.status === 'contract_signed').length;
    return `📊 **Estadísticas de la plataforma:**\n\n- 👥 Cash Buyers: **${buyers.length}**\n- 🏠 Seller Leads: **${leads.length}**\n- ✅ Deals acordados: **${agreed}**\n- 📝 Contratos firmados: **${signed}**\n- 📸 Creadores IG: **${(db.igCreators || []).length}**\n- 📚 Skills activos: **${(db.skills || []).length}**`;
  }
  if (msg.includes('buyer')) {
    return `Tengo **${buyers.length} cash buyers** registrados en la plataforma.\n\nTop 3:\n${buyers.slice(0, 3).map((b: any) => `• **${b.name}** — ${b.market} — ${b.buyBoxType} — Hasta ${b.maxPrice}`).join('\n')}\n\nPuedes pedirme que busque más buyers, agregue uno nuevo o scrape redes sociales.`;
  }
  if (msg.includes('lead') || msg.includes('vendedor') || msg.includes('propiedad')) {
    return `Tengo **${leads.length} seller leads** en el pipeline.\n\nTop 3:\n${leads.slice(0, 3).map((l: any) => `• **${l.ownerName}** — ${l.propertyAddress} — ARV: \$${l.estimatedArv?.toLocaleString()} — Estado: ${l.status}`).join('\n')}\n\nPuedes pedirme que ejecute el Auto-Pilot para generar más leads automáticamente.`;
  }
  return `Hola! Soy el Asistente IA de WholesalePlatform. Tengo acceso completo a tu plataforma:\n\n- **${buyers.length}** cash buyers registrados\n- **${leads.length}** seller leads activos\n- **${(db.skills || []).length}** estrategias de wholesale\n\n**Puedo hacer:**\n• Generar el Deal Pack completo para Richard Taylor (Excel, Word, Teléfonos, Scripts y Contrato)\n• Ejecutar el Auto-Pilot de búsqueda\n• Darte estadísticas de tu pipeline\n• Buscar nuevos buyers en Facebook/Reddit\n• Analizar una propiedad con SkyDrive Vision\n• Agregar leads o buyers manualmente`;
}
